import { HttpInterceptorFn } from '@angular/common/http';

export const randomInterceptor: HttpInterceptorFn = (req, next) => {
  return next(req);
};
