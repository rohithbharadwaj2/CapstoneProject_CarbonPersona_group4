import { Routes } from '@angular/router';
import { HomeComponent } from './pages/home/home.component';
import { LoginComponent } from './pages/login/login.component';
import { NavigationBarComponent } from './pages/navigation-bar/navigation-bar.component';
import { authGuard } from './services/auth.guard';
import { DashBoardComponent } from './pages/dashboard/dashboard.component';
import { ProfileComponent } from './pages/profile/profile.component';
import { UpdateComponent } from './pages/update/update.component';

export const routes: Routes = [
    {path:"",redirectTo:"login",pathMatch:'full'},
    {path:"login",component:LoginComponent},
    {path:"", component:NavigationBarComponent,
        children:[
            {path:"home",component: HomeComponent},
            {path:"dashboard",component:DashBoardComponent,data:{role :"Admin"}},
            {path:"profile",component:ProfileComponent,},
            {path:"update",component:UpdateComponent,},
            
        ]},
     
];
